# NGEIMA APP

A Pen created on CodePen.

Original URL: [https://codepen.io/Umaru-Brima-Ensah/pen/jEbyxzG](https://codepen.io/Umaru-Brima-Ensah/pen/jEbyxzG).

For a browser and mobile chatting app