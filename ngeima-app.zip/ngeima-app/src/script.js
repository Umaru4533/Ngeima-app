// Handle dropdown menu toggle
function toggleMenu() {
  const menu = document.getElementById("dropdown-menu");
  menu.style.display = menu.style.display === "block" ? "none" : "block";
}

// Close menu if clicking outside
window.onclick = function (event) {
  const menu = document.getElementById("dropdown-menu");
  if (!event.target.matches(".menu-icon")) {
    menu.style.display = "none";
  }
};

// Tab switcher
function switchTab(tabName) {
  const tabs = document.querySelectorAll(".tab");
  tabs.forEach((tab) => tab.classList.remove("active"));
  document
    .querySelector(`.tab[onclick="switchTab('${tabName}')"]`)
    .classList.add("active");

  const content = document.getElementById("tab-content");

  switch (tabName) {
    case "chats":
      content.innerHTML =
        "<h2>Chats</h2><p>Your personal chats will appear here.</p>";
      break;
    case "unread":
      content.innerHTML =
        "<h2>Unread</h2><p>Unread messages will appear here.</p>";
      break;
    case "favorite":
      content.innerHTML =
        "<h2>Favorite</h2><p>Your favorite chats will be shown here.</p>";
      break;
    case "groups":
      content.innerHTML =
        "<h2>Groups</h2><p>Your group chats will be shown here.</p>";
      break;
    case "status":
      content.innerHTML =
        "<h2>Status</h2><p>View or update your status here.</p>";
      break;
    default:
      content.innerHTML = "<p>Select a tab to see its content.</p>";
  }
}
